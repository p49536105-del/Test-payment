require("dotenv").config();

const express = require("express");
const path = require("path");
const Razorpay = require("razorpay");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const { RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET } = process.env;
const PORT = Number(process.env.PORT) || 3000;

if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) {
  console.error("ERROR: .env file mein Razorpay Key ID aur Key Secret set karein.");
  process.exit(1);
}

const razorpay = new Razorpay({
  key_id: RAZORPAY_KEY_ID,
  key_secret: RAZORPAY_KEY_SECRET
});

// Amount rupees mein bhejein; Razorpay API ko paise mein convert kiya jayega.
app.post("/api/create-order", async (req, res) => {
  try {
    const amount = Number(req.body.amount);
    const currency = String(req.body.currency || "INR").toUpperCase();

    if (!Number.isFinite(amount) || amount <= 0 || amount > 1000000) {
      return res.status(400).json({
        success: false,
        message: "Valid amount bhejein. Amount rupees mein hona chahiye."
      });
    }

    if (currency !== "INR") {
      return res.status(400).json({
        success: false,
        message: "Is demo mein filhaal sirf INR supported hai."
      });
    }

    const order = await razorpay.orders.create({
      amount: Math.round(amount * 100),
      currency,
      receipt: `receipt_${Date.now()}`
    });

    return res.json({
      success: true,
      order_id: order.id,
      amount: order.amount,
      currency: order.currency,
      key_id: RAZORPAY_KEY_ID
    });
  } catch (error) {
    console.error("Razorpay order creation error:", error);
    return res.status(500).json({
      success: false,
      message: "Order create nahi hua. Server logs aur Razorpay keys check karein."
    });
  }
});

app.get("/api/health", (req, res) => {
  res.json({ success: true, message: "Razorpay server is running" });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
