# Razorpay GitHub Project (Hindi)

## Is project mein kya hai?
- `.env` file: aapki Razorpay Live Key ID aur Key Secret yahin paste hongi.
- `server.js`: Express backend aur Razorpay Order Create API.
- `public/index.html`: amount daal kar Order ID banane ka test page.
- `package.json`: project dependencies.
- `.gitignore`: `.env` aur `node_modules` ko Git se ignore karta hai.

## 1. Keys kahan paste karni hain?
Project folder ki `.env` file kholein:

```env
RAZORPAY_KEY_ID=rzp_live_YOUR_KEY_ID
RAZORPAY_KEY_SECRET=YOUR_LIVE_KEY_SECRET
PORT=3000
```

`=` ke baad apni asli Live Key ID aur Live Key Secret paste karein. Placeholder text ko replace karein. Secret ko kisi ke saath share na karein.

## 2. Termux / computer par chalayein
Project folder mein terminal kholkar:

```bash
npm install
npm start
```

Phir browser mein `http://localhost:3000` kholein.

## 3. Order ID kaise banegi?
Page par amount rupees mein daalein, jaise `100`, phir **Create Order ID** dabayein. Backend `/api/create-order` Razorpay ko request bhejega aur `order_id` return karega.

## 4. GitHub par upload karte waqt
`.env` upload NA karein. `.gitignore` mein `.env` pehle se diya hai. GitHub par `.env.example` upload kar sakte hain. Agar `.env` kabhi public ho gayi ho to Razorpay Dashboard se keys turant rotate karein.

## Important
- Live mode mein asli paise ka transaction ho sakta hai.
- Yeh starter project Order ID create karta hai; yeh akela payment capture/verification ya refund system nahi hai.
- Real payment checkout launch karne se pehle server-side signature verification, webhook verification, HTTPS, input validation, rate limiting aur proper testing add karein.
- Razorpay Secret Key kabhi frontend (`public/index.html`) ya GitHub mein na daalein.
